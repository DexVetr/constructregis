import {test} from 'node:test';
import assert from 'node:assert/strict';
import {applyOperation,emptyState} from '../lib/demo-store.ts';
import {journalRows,moscowDate} from '../lib/domain.ts';
test('пример → возврат → исправление → подтверждение → журнал; повторная отправка безопасна',()=>{
 let s=applyOperation(emptyState(),{id:'seed',action:'example'});
 assert.equal(s.assignments.length,3);assert.equal(journalRows(s.assignments,s.reports,Number(moscowDate().slice(0,4))).length,0);
 const reportId=s.reports[0].id;
 s=applyOperation(s,{id:'return',action:'return',reportId,version:1,reviewNote:'Уточнить объём'});
 s=applyOperation(s,{id:'revise',action:'revise',reportId,version:2,quantity:'24,5',workDate:moscowDate(),shift:'Дневная'});
 assert.throws(()=>applyOperation(s,{id:'stale',action:'confirm',reportId,version:1}));
 const payload={id:'confirm',action:'confirm',reportId,version:3};
 s=applyOperation(s,payload);assert.deepEqual(applyOperation(s,payload),s);
 const rows=journalRows(s.assignments,s.reports,Number(moscowDate().slice(0,4)));
 assert.equal(rows[0].yearTotal,24.5);
 s=applyOperation(s,{id:'clear',action:'clear_reports',confirmation:'delete-test-data'});
 assert.equal(s.reports.length,0);assert.equal(s.assignments.length,3);
});
test('неверные данные не меняют исходное состояние',()=>{
 const s=applyOperation(emptyState(),{id:'seed',action:'example'});
 assert.throws(()=>applyOperation(s,{id:'bad',action:'report',assignmentId:s.assignments[0].id,quantity:-1,shift:'Дневная',workDate:moscowDate()}));
 assert.equal(s.reports.length,1);
 assert.throws(()=>applyOperation(s,{id:'clear',action:'clear_assignments'}));
});
