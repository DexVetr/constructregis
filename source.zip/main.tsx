import React from 'react';
import {createRoot} from 'react-dom/client';
import Pilot from './app/pilot';
import './app/pilot.css';
createRoot(document.getElementById('root')!).render(<><div className="demo-banner">Открытая демоверсия · Только учебные данные · Изменения сохраняются в этом браузере и не видны другим посетителям</div><Pilot/></>);
