import {useEffect,useRef,useState} from 'react';
import {Trash2,X} from 'lucide-react';
import type {CleanupKind} from '../lib/test-cleanup';

type Props = {
  assignments: number;
  reports: number;
  enabled: boolean;
  busy: boolean;
  onClear: (kind: CleanupKind, operation: string) => Promise<boolean>;
};

export default function CleanupControls({assignments,reports,enabled,busy,onClear}: Props) {
  const dialog = useRef<HTMLDialogElement>(null);
  const [pending,setPending] = useState<{kind:CleanupKind;id:string}|null>(null);
  const [failed,setFailed] = useState(false);
  useEffect(() => {
    if (pending) dialog.current?.showModal();
    else dialog.current?.close();
  }, [pending]);
  function open(kind:CleanupKind) {
    setFailed(false);
    setPending({kind,id:crypto.randomUUID()});
  }
  async function confirm() {
    if (!pending || busy || !enabled) return;
    setFailed(false);
    if (await onClear(pending.kind,pending.id)) setPending(null);
    else setFailed(true);
  }
  const all = pending?.kind === 'clear_assignments';
  return <>
    <section className="test-cleanup" aria-label="Очистка тестовых данных">
      <div><strong>Тестовые данные</strong><p>Очистка учебных данных в этом браузере</p></div>
      <div className="cleanup-actions">
        <button className="button cleanup-button" disabled={!enabled||busy||!reports} onClick={()=>open('clear_reports')}><Trash2 size={16}/>Удалить все записи</button>
        <button className="button cleanup-button" disabled={!enabled||busy||!assignments} onClick={()=>open('clear_assignments')}><Trash2 size={16}/>Удалить все задания</button>
      </div>
    </section>
    <dialog ref={dialog} className="cleanup-dialog" aria-labelledby="cleanup-title" aria-describedby="cleanup-description" onCancel={e=>{if(busy)e.preventDefault();else setPending(null);}} onClose={()=>{if(!busy)setPending(null);}}>
      <div className="cleanup-dialog-heading"><span className="cleanup-symbol"><Trash2 size={22}/></span><button className="icon-button" aria-label="Закрыть окно удаления" disabled={busy} onClick={()=>setPending(null)}><X size={19}/></button></div>
      <h2 id="cleanup-title">{all?'Удалить все задания?':'Удалить все записи выполнения?'}</h2>
      <div id="cleanup-description"><p>В этом браузере будут удалены {all?<>задания ({assignments}) и связанные записи выполнения ({reports})</>:<>записи выполнения ({reports}), включая подтвержденные объемы</>}.</p><p>{all?'Журнал КС-6а станет пустым.':'Задания сохранятся, а объемы в журнале КС-6а будут очищены.'} Черновики объемов на этом устройстве также будут очищены.</p><p className="cleanup-warning">Отменить удаление нельзя. История действий сохранится.</p></div>
      {failed&&<p className="cleanup-warning" role="alert">Браузер не сохранил очистку. Проверьте доступ к хранилищу и повторите действие либо закройте окно и обновите данные.</p>}
      <div className="cleanup-dialog-actions"><button autoFocus className="button secondary" disabled={busy} onClick={()=>setPending(null)}>Отмена</button><button className="button destructive" disabled={!enabled||busy} onClick={()=>void confirm()}>{busy?'Удаляем…':all?'Удалить задания и записи':'Удалить записи'}</button></div>
    </dialog>
  </>;
}
