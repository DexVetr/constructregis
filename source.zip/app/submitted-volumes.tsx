import {Check,Clock,MapPin,Plus,RotateCcw} from 'lucide-react';
import {number,type Assignment,type WorkReport} from '../lib/domain';
import {assignmentProgress} from '../lib/foreman-progress';

type Props = {assignments:Assignment[];reports:WorkReport[];expanded:Set<string>;busy:boolean;onExpand:(id:string)=>void};
function dateText(date:string){return new Date(date+'T12:00:00Z').toLocaleDateString('ru-RU',{day:'numeric',month:'short',timeZone:'Europe/Moscow'});}
function statusText(status:string){return status==='confirmed'?'Подтверждено':status==='returned'?'На уточнении':'На проверке';}

export default function SubmittedVolumes({assignments,reports,expanded,busy,onExpand}:Props){
  const groups = assignments.map(assignment=>({assignment,entries:reports.filter(r=>r.assignmentId===assignment.id).sort((a,b)=>b.submittedAt.localeCompare(a.submittedAt))})).filter(g=>g.entries.length>0).sort((a,b)=>b.entries[0].submittedAt.localeCompare(a.entries[0].submittedAt));
  return <section className="submitted-section" aria-label="Переданные объёмы">
    <div className="section-heading secondary-heading"><h2>Переданные объёмы <span>{groups.length}</span></h2><span className="muted">По заданиям вашей бригады</span></div>
    {groups.length===0?<p className="submitted-empty">После передачи на проверку форма свернется, а объем появится в этом списке.</p>:<div className="submitted-list">{groups.map(({assignment:a,entries})=>{
      const progress=assignmentProgress(a,entries);const last=entries[0];const hasReturned=entries.some(r=>r.status==='returned');
      return <article className="submitted-card" key={a.id} id={'submitted-'+a.id} aria-label={'Переданные объёмы: '+a.work}>
        <div className="submitted-card-top"><div><h3>{a.work}</h3><p className="place"><MapPin size={14}/>{a.location}</p><p className="submitted-document">{a.document}</p></div><span className={'badge '+(progress.incomplete?'plan-incomplete':'plan-submitted')}>{progress.incomplete?'План не выполнен':'План заявлен полностью'}</span></div>
        <div className="submitted-progress"><span>Передано по заданию <strong>{number(progress.submitted)} из {number(a.planned)} {a.unit}</strong></span><div className="progress-track"><div style={{width:Math.min(100,progress.submitted/a.planned*100)+'%'}}/></div><span className="muted">Подтверждено: {number(progress.confirmed)} {a.unit} · На проверке: {number(progress.pending)} {a.unit}</span>{progress.incomplete&&<span className="submitted-remaining">Осталось передать: {number(progress.remaining)} {a.unit}</span>}</div>
        <div className="submitted-latest"><div><span className="small-label">Последняя передача</span><p>{dateText(last.workDate)} · {last.shift.toLowerCase()}</p></div><strong>{number(last.quantity)} {a.unit}</strong><span className={'badge '+last.status}>{last.status==='confirmed'?<Check size={13}/>:last.status==='returned'?<RotateCcw size={13}/>:<Clock size={13}/>} {statusText(last.status)}</span></div>
        <div className="submitted-card-actions">{hasReturned?<span className="small-warning">Исправьте возвращенный объем в форме выше.</span>:<button className="button secondary" disabled={busy||expanded.has(a.id)} onClick={()=>onExpand(a.id)}><Plus size={16}/>{expanded.has(a.id)?'Форма открыта выше':'Добавить объём'}</button>}{entries.length>1&&<details className="submitted-history"><summary>Все передачи ({entries.length})</summary><div>{entries.map(r=><div className="submitted-history-row" key={r.id}><span>{dateText(r.workDate)} · {r.shift.toLowerCase()}</span><strong>{number(r.quantity)} {a.unit}</strong><span className={'badge '+r.status}>{statusText(r.status)}</span>{r.note&&<p>{r.note}</p>}{r.status==='returned'&&<p className="small-warning">Замечание: {r.reviewNote}</p>}</div>)}</div></details>}</div>
      </article>;
    })}</div>}
    {groups.length>0&&<p className="help submitted-help">Метка плана учитывает переданные и подтвержденные объемы. В КС-6а попадают только объемы, подтвержденные инженером.</p>}
  </section>;
}
