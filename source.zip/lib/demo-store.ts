import {type PilotData,quantity,required,optionalNumber,validDate,moscowDate} from './domain.ts';
export const STORAGE_KEY='route-fact-demo-v1';
type Payload=Record<string,unknown>;
type State=PilotData & {operations:string[]};
export function emptyState():State{return {assignments:[],reports:[],events:[],user:'Демо',operations:[]};}
export function applyOperation(input:State,p:Payload):State{
 const s=structuredClone(input),id=required(p.id,'Номер операции',100),now=new Date().toISOString();
 if(s.operations.includes(id))return s;
 const event=(entityId:string,action:string,detail='')=>s.events.unshift({id:id+'-event',entityId,action,detail,actor:'Демо',createdAt:now});
 if(p.action==='assignment'){
  const unit=required(p.unit,'Единица измерения',30);if(!['м³','м²','м','т','шт.','компл.'].includes(unit))throw Error('Выберите единицу измерения.');
  s.assignments.unshift({id,project:required(p.project,'Объект'),work:required(p.work,'Вид работ'),document:required(p.document,'Документация'),location:required(p.location,'Участок'),brigade:required(p.brigade,'Бригада',120),unit,planned:quantity(p.planned),position:String(p.position||'')||null,rateCode:String(p.rateCode||'')||null,estimateQuantity:optionalNumber(p.estimateQuantity),price:optionalNumber(p.price),createdAt:now});event(id,'Назначено задание');
 }else if(p.action==='report'){
  const assignmentId=required(p.assignmentId,'Задание',100);if(!s.assignments.some(a=>a.id===assignmentId))throw Error('Задание не найдено.');
  const shift=required(p.shift,'Смена',30);if(!['Дневная','Ночная'].includes(shift))throw Error('Выберите смену.');
  const note=String(p.note||'');if(note.length>2000)throw Error('Комментарий слишком длинный.');
  s.reports.unshift({id,assignmentId,workDate:validDate(p.workDate),shift,quantity:quantity(p.quantity),note,status:'pending',submittedAt:now,checkedAt:null,reviewer:null,reviewNote:'',version:1});event(id,'Передано на проверку');
 }else if(['confirm','return','revise'].includes(String(p.action))){
  const r=s.reports.find(r=>r.id===p.reportId);if(!r)throw Error('Запись не найдена.');if(r.version!==p.version)throw Error('Запись изменилась. Обновите данные.');
  const revise=p.action==='revise';if(r.status!==(revise?'returned':'pending'))throw Error('Действие недоступно для текущего состояния записи.');
  const before=r.quantity;
  if(revise){r.quantity=quantity(p.quantity);r.workDate=validDate(p.workDate);r.shift=required(p.shift,'Смена',30);if(!['Дневная','Ночная'].includes(r.shift))throw Error('Выберите смену.');r.note=String(p.note||'');if(r.note.length>2000)throw Error('Комментарий слишком длинный.');}
  r.reviewNote=p.action==='return'?required(p.reviewNote,'Причина возврата',2000):'';r.status=revise?'pending':p.action==='confirm'?'confirmed':'returned';r.checkedAt=revise?null:now;r.reviewer=revise?null:'Инженер (демо)';r.version++;
  event(r.id,revise?'Исправлено и передано повторно':p.action==='confirm'?'Объем подтвержден':'Возвращено на уточнение',revise?JSON.stringify({before,after:r.quantity}):r.reviewNote);
 }else if(p.action==='example'){
  const examples=[['Бетонирование ростверка','Опора № 7 · захватка 1','Бригада № 1','м³',120,8500],['Монтаж арматурного каркаса','Опора № 8 · оси А–Б','Бригада № 2','т',18,32000],['Гидроизоляция ростверка','Опора № 7 · захватка 2','Бригада № 1','м²',240,950]] as const;
  examples.forEach((x,i)=>{const aid='demo-example-'+i;if(!s.assignments.some(a=>a.id===aid))s.assignments.push({id:aid,project:'Мостовой переход · учебный объект',work:x[0],document:'РД-КЖ-07 · лист '+(12+i),location:x[1],brigade:x[2],unit:x[3],planned:x[4],position:String(i+1),rateCode:'Учебная расценка',estimateQuantity:x[4],price:x[5],createdAt:now});});
  if(!s.reports.some(r=>r.id==='demo-example-report'))s.reports.push({id:'demo-example-report',assignmentId:'demo-example-0',workDate:moscowDate(),shift:'Дневная',quantity:35,note:'Учебная запись для проверки инженером',status:'pending',submittedAt:now,checkedAt:null,reviewer:null,reviewNote:'',version:1});event('demo-example-0','Добавлен учебный пример');
 }else if(p.action==='clear_reports'||p.action==='clear_assignments'){
  if(p.confirmation!=='delete-test-data')throw Error('Подтвердите удаление.');s.reports=[];if(p.action==='clear_assignments')s.assignments=[];event('test-data','Удалены тестовые данные');
 }else throw Error('Неизвестное действие.');
 s.operations.push(id);return s;
}
export function loadDemo():State{
 const raw=localStorage.getItem(STORAGE_KEY);if(raw)return JSON.parse(raw);
 const seed=applyOperation(emptyState(),{action:'example',id:'initial-example'});localStorage.setItem(STORAGE_KEY,JSON.stringify(seed));return seed;
}
