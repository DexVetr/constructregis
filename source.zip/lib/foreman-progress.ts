import {sum, type Assignment, type WorkReport} from './domain.ts';

export function assignmentProgress(assignment: Assignment, reports: WorkReport[]) {
  const entries = reports.filter(r=>r.assignmentId===assignment.id);
  const confirmed = sum(entries.filter(r=>r.status==='confirmed').map(r=>r.quantity));
  const pending = sum(entries.filter(r=>r.status==='pending').map(r=>r.quantity));
  const submitted = sum([confirmed,pending]);
  return {confirmed,pending,submitted,remaining:Math.max(0,sum([assignment.planned,-submitted])),incomplete:submitted<assignment.planned};
}

export function showAssignmentEntry(id: string, reports: WorkReport[], expanded: boolean, draftId?: string, collapsed = false) {
  const entries = reports.filter(r=>r.assignmentId===id);
  const unsentDraft = !!draftId && !entries.some(r=>r.id===draftId);
  return expanded || (!collapsed && unsentDraft) || entries.length===0;
}

// Keep the acknowledged submission visible even if the follow-up GET fails.
// A newer server version always takes precedence over this local fallback.
export function mergeSubmittedReport(reports: WorkReport[], submitted: WorkReport) {
  const existing = reports.find(r=>r.id===submitted.id);
  if (existing && existing.version>=submitted.version) return reports;
  return [submitted,...reports.filter(r=>r.id!==submitted.id)];
}
