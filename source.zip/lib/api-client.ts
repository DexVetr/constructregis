import {applyOperation,loadDemo,STORAGE_KEY} from './demo-store';
export function connectionMessage(error:unknown){return error instanceof Error?error.message:'Не удалось сохранить данные в браузере.';}
export async function requestJson<T>(url:string,init:RequestInit={}):Promise<T>{
 if(url!=='/api/pilot')throw Error('Неизвестный запрос демоверсии.');
 const data=loadDemo();
 if(init.method?.toUpperCase()==='POST'){
  const next=applyOperation(data,JSON.parse(String(init.body)));localStorage.setItem(STORAGE_KEY,JSON.stringify(next));return {ok:true} as T;
 }
 return data as T;
}
