export type CleanupKind = 'clear_reports' | 'clear_assignments';
export type CleanupStatement = {sql: string; values: string[]};

// D1 batch executes these statements atomically. Keep the operation marker so
// a repeated request cannot erase data entered after the first cleanup.
export function cleanupStatements(kind: CleanupKind, owner: string, operation: string, actor: string, now: string): CleanupStatement[] {
  const marker = owner + ':cleanup:' + operation;
  const guard = 'NOT EXISTS (SELECT 1 FROM events WHERE id=? AND owner_id=?)';
  const statements: CleanupStatement[] = [{
    sql: 'DELETE FROM reports WHERE owner_id=? AND ' + guard,
    values: [owner, marker, owner],
  }];
  if (kind === 'clear_assignments') statements.push({
    sql: 'DELETE FROM assignments WHERE owner_id=? AND ' + guard,
    values: [owner, marker, owner],
  });
  statements.push({
    sql: 'INSERT OR IGNORE INTO events (id,owner_id,entity_id,action,actor,detail,created_at) VALUES (?,?,?,?,?,?,?)',
    values: [marker, owner, 'test-data', kind === 'clear_assignments' ? 'Удалены все задания и записи' : 'Удалены все записи выполнения', actor,
      'Очистка тестовых данных во всех объектах аккаунта. История действий сохранена.', now],
  });
  return statements;
}
